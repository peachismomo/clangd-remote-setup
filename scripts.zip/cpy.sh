#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
INSTALL_DIR="${ORCA_CLANGD_SCRIPT_DIR:-"$HOME/scripts/clangd-server"}"

scripts=(
  generate-remote-clangd-index.sh
  run-clangd-index-server.sh
  setup-worktree-clangd-remote-index.sh
)

mkdir -p "$INSTALL_DIR"

for script in "${scripts[@]}"; do
  if [[ ! -f "$SCRIPT_DIR/$script" ]]; then
    echo "error: missing $SCRIPT_DIR/$script" >&2
    exit 1
  fi

  cp "$SCRIPT_DIR/$script" "$INSTALL_DIR/$script"
  chmod +x "$INSTALL_DIR/$script"
done

echo "Installed clangd remote-index helper scripts to:"
echo "  $INSTALL_DIR"
