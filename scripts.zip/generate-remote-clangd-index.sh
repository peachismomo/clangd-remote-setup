#!/usr/bin/env bash
set -euo pipefail

ROOT="$(git rev-parse --show-toplevel 2>/dev/null || pwd)"
BUILD_DIR="${BUILD_DIR:-"$ROOT/build"}"
CONFIG="${CONFIG:-RelWithDebInfo}"
INDEX_DIR="${INDEX_DIR:-"$ROOT/.clangd-remote-index"}"
COMPILE_DB="${COMPILE_DB:-"$BUILD_DIR/compile_commands.json"}"
LLVM_PREFIX="${LLVM_CLANGD_REMOTE_PREFIX:-"$HOME/opt/llvm-clangd-remote"}"
INDEXER="${CLANGD_INDEXER:-"$LLVM_PREFIX/bin/clangd-indexer"}"
QUERY_DRIVER="${QUERY_DRIVER:-/usr/bin/clang++,/usr/bin/clang,/usr/bin/g++,/usr/bin/gcc}"
FILTER="${FILTER:-}"
STRIP_PCH="${STRIP_PCH:-1}"
JOBS="${JOBS:-}"

die() {
    echo "error: $*" >&2
    exit 1
}

detect_resource_dir() {
    local major="$1"
    local candidates=()

    if [[ -n "$major" ]]; then
        candidates+=(
            "$LLVM_PREFIX/lib/clang/$major"
            "$HOME/repos/llvm-project/build/lib/clang/$major"
            "$HOME/opt/llvm-source/lib/clang/$major"
        )
    fi

    local candidate
    for candidate in "${candidates[@]}"; do
        if [[ -f "$candidate/include/float.h" ]]; then
            printf '%s\n' "$candidate"
            return 0
        fi
    done

    return 1
}

[[ -x "$INDEXER" ]] || die "clangd-indexer not found or not executable: $INDEXER"
[[ -f "$COMPILE_DB" ]] || die "compile_commands.json not found: $COMPILE_DB"
command -v python3 >/dev/null || die "python3 is required to filter compile_commands.json"

if [[ -z "$JOBS" ]]; then
    if command -v nproc >/dev/null; then
        JOBS="$(nproc)"
        if (( JOBS > 1 )); then
            JOBS="$((JOBS - 1))"
        fi
    else
        JOBS=4
    fi
fi

INDEXER_MAJOR="$("$INDEXER" --version | sed -n 's/.*LLVM version \([0-9][0-9]*\).*/\1/p' | head -n 1)"
RESOURCE_DIR="${CLANG_RESOURCE_DIR:-}"
if [[ -z "$RESOURCE_DIR" ]]; then
    RESOURCE_DIR="$(detect_resource_dir "$INDEXER_MAJOR")" || die "could not find clang builtin headers for LLVM $INDEXER_MAJOR; set CLANG_RESOURCE_DIR"
fi
[[ -f "$RESOURCE_DIR/include/float.h" ]] || die "clang resource dir is missing include/float.h: $RESOURCE_DIR"

mkdir -p "$INDEX_DIR/compile-db"
FILTERED_DB="$INDEX_DIR/compile-db/compile_commands.json"

ENTRY_COUNT="$(
    INPUT_DB="$COMPILE_DB" OUTPUT_DB="$FILTERED_DB" CONFIG="$CONFIG" STRIP_PCH="$STRIP_PCH" python3 - <<'PY'
import json
import os
import pathlib
import shlex

input_db = os.environ["INPUT_DB"]
output_db = os.environ["OUTPUT_DB"]
config = os.environ["CONFIG"]
strip_pch = os.environ.get("STRIP_PCH", "1") != "0"

with open(input_db, "r", encoding="utf-8") as fh:
    entries = json.load(fh)

has_multi_config = any("CMAKE_INTDIR=" in entry.get("command", "") for entry in entries)
config_tags = (f'CMAKE_INTDIR=\\"{config}\\"', f'CMAKE_INTDIR="{config}"')

def strip_pch_args(args):
    stripped = []
    i = 0
    while i < len(args):
        if args[i] == "-Winvalid-pch":
            i += 1
            continue
        if i + 3 < len(args) and args[i] == "-Xclang" and args[i + 1] == "-include-pch" and args[i + 2] == "-Xclang":
            i += 4
            continue
        stripped.append(args[i])
        i += 1
    return stripped

filtered = []
for entry in entries:
    command = entry.get("command", "")
    if has_multi_config and not any(tag in command for tag in config_tags):
        continue

    file_name = pathlib.PurePath(entry.get("file", "")).name
    if file_name == "cmake_pch.hxx.cxx":
        continue

    entry = dict(entry)
    if strip_pch:
        if "arguments" in entry:
            entry["arguments"] = strip_pch_args(entry["arguments"])
        elif command:
            entry["command"] = shlex.join(strip_pch_args(shlex.split(command)))
    filtered.append(entry)

with open(output_db, "w", encoding="utf-8") as fh:
    json.dump(filtered, fh, indent=2)
    fh.write("\n")

print(len(filtered))
PY
)"

[[ "$ENTRY_COUNT" != "0" ]] || die "filtered compile database is empty for CONFIG=$CONFIG"

INDEX_FILE="$INDEX_DIR/clangd.dex"
TMP_INDEX="$INDEX_FILE.tmp.$$"
LOG_FILE="$INDEX_DIR/clangd-indexer.log"
FILTER_ARGS=()
if [[ -n "$FILTER" ]]; then
    FILTER_ARGS+=(--filter="$FILTER")
fi

echo "Index source root: $ROOT"
echo "Compile database: $FILTERED_DB ($ENTRY_COUNT entries, CONFIG=$CONFIG, STRIP_PCH=$STRIP_PCH)"
echo "clang resource dir: $RESOURCE_DIR"
echo "Output index: $INDEX_FILE"

rm -f "$TMP_INDEX"
rm -f "$LOG_FILE"
cleanup() {
    rm -f "$TMP_INDEX"
}
trap cleanup EXIT

if ! "$INDEXER" \
    --executor=all-TUs \
    --execute-concurrency="$JOBS" \
    --query-driver="$QUERY_DRIVER" \
    --extra-arg-before="-resource-dir=$RESOURCE_DIR" \
    --extra-arg=-Wno-unknown-warning-option \
    "${FILTER_ARGS[@]}" \
    "$FILTERED_DB" > "$TMP_INDEX" 2> >(tee "$LOG_FILE" >&2); then
    die "clangd-indexer failed; see $LOG_FILE"
fi

if grep -Eq "Failed to run action|Error while processing|fatal error:" "$LOG_FILE"; then
    die "clangd-indexer reported translation-unit errors; see $LOG_FILE"
fi

[[ -s "$TMP_INDEX" ]] || die "indexer produced an empty index"
mv "$TMP_INDEX" "$INDEX_FILE"
trap - EXIT
echo "Wrote $INDEX_FILE"
