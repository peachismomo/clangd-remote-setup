#!/usr/bin/env bash
set -euo pipefail

ROOT="$(git rev-parse --show-toplevel 2>/dev/null || pwd)"
LLVM_PREFIX="${LLVM_CLANGD_REMOTE_PREFIX:-"$HOME/opt/llvm-clangd-remote"}"
SERVER_BIN="${CLANGD_INDEX_SERVER:-"$LLVM_PREFIX/bin/clangd-index-server"}"
INDEX_FILE="${INDEX_FILE:-"$ROOT/.clangd-remote-index/clangd.dex"}"
PROJECT_ROOT="${INDEX_PROJECT_ROOT:-"$ROOT"}"
SERVER_ADDRESS="${CLANGD_INDEX_SERVER_ADDRESS:-127.0.0.1:5900}"

[[ -x "$SERVER_BIN" ]] || { echo "error: clangd-index-server not found or not executable: $SERVER_BIN" >&2; exit 1; }
[[ -s "$INDEX_FILE" ]] || { echo "error: index file missing or empty: $INDEX_FILE" >&2; exit 1; }
[[ -d "$PROJECT_ROOT" ]] || { echo "error: project root does not exist: $PROJECT_ROOT" >&2; exit 1; }

echo "Serving $INDEX_FILE"
echo "Project root: $PROJECT_ROOT"
echo "Address: $SERVER_ADDRESS"
exec "$SERVER_BIN" --server-address="$SERVER_ADDRESS" "$INDEX_FILE" "$PROJECT_ROOT"
